<template>
    <!-- Footer -->
    <footer class="blog-footer">
        <p>SPA Laravel-Vue Blog</p>
        <p>
            <a href="#">Back to top</a>
        </p>
        <router-link to="/login" class="text-right">Administration</router-link>
    </footer>
    <!-- End Foooter -->
</template>

<script>
    export default {
        name: "Footer"
    }
</script>

<style scoped>

</style>
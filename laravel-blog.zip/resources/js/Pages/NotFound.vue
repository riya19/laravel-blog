<template>
    <div class="row col-md-8">
        <div class="col-md-12 ">
            <h1 class="pb-4 mb-4 font-italic text-center">
                404 | Not Found
            </h1>
        </div>
    </div>
</template>

<script>
    export default {
        name: "NotFound"
    }
</script>